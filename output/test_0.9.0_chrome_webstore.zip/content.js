$('#lst-ib').change(function() {
  alert($('#lst-ib').val());
});

